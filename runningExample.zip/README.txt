1. $ git clone https://github.com/joekurta/constrained-shortest-common-supersequence
2. $ cd constrained-shortest-common-supersequence
3. copy files from this folder into "constrained-shortest-common-supersequence" folder
3. $ ./cs-algorithm seq1-50000.txt seq2-10000.txt constraints.txt out.txt 70000
